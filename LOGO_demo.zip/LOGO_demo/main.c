/*
 * ֻ��*�ַ����Զ�������߱���+�Ҷ���ֵ
 * ֧��0/1��0~9���ؾ���
 * ���룺gcc -o logo_star logo_star.c
 * ���У�./logo_star matrix.txt
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* �ɵ����� */
#define HORIZONTAL_SCALE 2   // ��������������2��3���Ƽ�2��
#define THRESHOLD '5'        // ��ֵ������ֵ>=THRESHOLD�����*

// �Ҷ��ַ������Ӻڵ��ף�˳������.txtһ�£�
const char* GRAYSCALE = "#@&B5J!~?7YPG ";
// ��ֵ��������5����ʾ�ȵ�5���ַ������ڡ��Ķ����*��
#define GRAYSCALE_THRESHOLD 5

// ȫ�ֱ���
static char* logo = NULL;
static int total_lines = 0, line_len = 0;
#define WIN_MARGIN 40 // ���ڱ߾�
static int font_height = 12;
static int font_width = 6;
#define FONT_HEIGHT_MIN 6
#define FONT_HEIGHT_MAX 48

// ��ȡ���ؾ����ļ������ض�̬�����logo�ַ���
char* load_logo(const char* filename) {
    FILE* fp = fopen(filename, "r");
    if (!fp) return NULL;
    char** lines = (char**)malloc(2048 * sizeof(char*));
    int row = 0, col = -1;
    char line[2048];
    while (fgets(line, sizeof(line), fp)) {
        int len = (int)strcspn(line, "\r\n");
        line[len] = '\0';
        if (col == -1) col = len;
        lines[row] = (char*)malloc((col+1) * sizeof(char));
        strcpy(lines[row], line);
        row++;
    }
    fclose(fp);
    total_lines = row;
    line_len = col;

    // ����logo�ַ���
    int gs_len = (int)strlen(GRAYSCALE);
    int bufsize = (col * HORIZONTAL_SCALE + 2) * row + 1;
    char* logo = (char*)malloc(bufsize);
    int pos = 0;
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            char c = lines[i][j];
            int idx = gs_len - 1;
            for (int k = 0; k < gs_len; ++k) {
                if (c == GRAYSCALE[k]) { idx = k; break; }
            }
            char outch = (idx > GRAYSCALE_THRESHOLD) ? '*' : ' ';
            for (int h = 0; h < HORIZONTAL_SCALE; ++h)
                logo[pos++] = outch;
        }
        logo[pos++] = '\0'; // ÿ�н�β
        free(lines[i]);
    }
    free(lines);
    logo[pos] = '\0';
    return logo;
}

// Win32���ڹ���
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE:
        logo = load_logo("matrix.txt");
        if (!logo) {
            MessageBox(hwnd, "δ�ҵ�matrix.txt���ļ���ʽ����", "����", MB_OK | MB_ICONERROR);
            PostQuitMessage(0);
        }
        break;
    case WM_MOUSEWHEEL: {
        if (GetKeyState(VK_CONTROL) & 0x8000) { // Ctrl����
            int delta = GET_WHEEL_DELTA_WPARAM(wParam);
            if (delta > 0 && font_height < FONT_HEIGHT_MAX) {
                font_height += 2; font_width += 1;
            } else if (delta < 0 && font_height > FONT_HEIGHT_MIN) {
                font_height -= 2; if (font_width > 2) font_width -= 1;
            }
            // ���ź��Զ��������ڴ�С����֤�ͻ���������ʾlogo
            int win_width = line_len * HORIZONTAL_SCALE * font_width + WIN_MARGIN;
            int win_height = total_lines * font_height + WIN_MARGIN;
            RECT rect = {0, 0, win_width, win_height};
            DWORD style = WS_OVERLAPPEDWINDOW;
            AdjustWindowRectEx(&rect, style, FALSE, 0);
            int real_width = rect.right - rect.left;
            int real_height = rect.bottom - rect.top;
            SetWindowPos(hwnd, NULL, 0, 0, real_width, real_height, SWP_NOMOVE | SWP_NOZORDER);
            InvalidateRect(hwnd, NULL, TRUE);
        }
        break;
    }
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        HFONT hFont = CreateFont(
            font_height, font_width, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET,
            OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, "Consolas"
        );
        SelectObject(hdc, hFont);
        RECT rect;
        GetClientRect(hwnd, &rect);

        // ������ʾlogo
        int logo_pixel_width = line_len * HORIZONTAL_SCALE * font_width;
        int logo_pixel_height = total_lines * font_height;
        int x0 = (rect.right - rect.left - logo_pixel_width) / 2;
        int y0 = (rect.bottom - rect.top - logo_pixel_height) / 2;
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;

        for (int i = 0; i < total_lines; ++i) {
            TextOut(
                hdc,
                x0,
                y0 + i * font_height,
                logo + i * (line_len * HORIZONTAL_SCALE + 1),
                line_len * HORIZONTAL_SCALE
            );
        }

        DeleteObject(hFont);
        EndPaint(hwnd, &ps);
        break;
    }
    case WM_DESTROY:
        if (logo) free(logo);
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

// WinMain���
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    WNDCLASS wc = {0};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "LogoWin";
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    RegisterClass(&wc);

    // ��ʼ���ڴ�С����logo
    int win_width = 800, win_height = 600;
    if (logo) {
        win_width = line_len * HORIZONTAL_SCALE * font_width + WIN_MARGIN;
        win_height = total_lines * font_height + WIN_MARGIN;
        RECT rect = {0, 0, win_width, win_height};
        DWORD style = WS_OVERLAPPEDWINDOW;
        AdjustWindowRectEx(&rect, style, FALSE, 0);
        win_width = rect.right - rect.left;
        win_height = rect.bottom - rect.top;
    }
    HWND hwnd = CreateWindow("LogoWin", "Logo ASCII Art", WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, win_width, win_height, NULL, NULL, hInstance, NULL);
    ShowWindow(hwnd, nCmdShow);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return 0;
}

